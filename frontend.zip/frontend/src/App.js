import React from 'react';
import MovieSearchPage from './MovieSearchPage';
import MoviePage from './MoviePage';

const App = () => {
  return (
    <div className='App'> 
      <MovieSearchPage/>
    </div>
    
  );
};

export default App;
