import Grid from '@mui/material/Grid';
import React, { useEffect, useState } from 'react';
import Box from '@mui/material/Box';


const MoviePage = () => {
  // const movies = [
  //   {
  //     name: 'Movie 1',
  //     releaseDate: '2022',
  //     summary: 'Summary of Movie 1',
  //     userRating: '4.5',
  //     websiteRating: '8.2',
  //   },
  //   {
  //     name: 'Movie 2',
  //     releaseDate: '2021',
  //     summary: 'Summary of Movie 2',
  //     userRating: '4.0',
  //     websiteRating: '7.9',
  //   },
  //   {
  //     name: 'Movie 2',
  //     releaseDate: '2021',
  //     summary: 'Summary of Movie 2',
  //     userRating: '4.0',
  //     websiteRating: '7.9',
  //   },
  //   {
  //     name: 'Movie 2',
  //     releaseDate: '2021',
  //     summary: 'Summary of Movie 2',
  //     userRating: '4.0',
  //     websiteRating: '7.9',
  //   },
  //   {
  //     name: 'Movie 2',
  //     releaseDate: '2021',
  //     summary: 'Summary of Movie 2',
  //     userRating: '4.0',
  //     websiteRating: '7.9',
  //   },
  //   {
  //     name: 'Movie 2',
  //     releaseDate: '2021',
  //     summary: 'Summary of Movie 2',
  //     userRating: '4.0',
  //     websiteRating: '7.9',
  //   },
  //   // Add more movie objects as needed
  // ];

  const [movie, setMovies] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
        try {
            const response = await fetch('http://127.0.0.1:5000/api/movies');
            const data = await response.json();
            setMovies(data);
            console.log(data)
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    fetchData();
}, []);

return (
  <div>
  <br/>
  <br/>
  <br/>
  <Box sx={{ flexGrow: 1}}>
    <Grid container spacing={2} sx={{ backgroundColor: 'linear-gradient(135deg, #f6d365, #fda085)'}}>
      {movie.map((movie, index) => (
        <Grid item key={index} xs={12} sm={6} md={4} lg={3}>
          <div style={{ background: '#f9f9f9', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
            <h2>{movie.name}</h2>
            <p><strong>Release Date:</strong> {movie.release_date}</p>
            <p><strong>Summary:</strong> {movie.summary.length > 200 ? `${movie.summary.substring(0, 200)}...` : movie.summary}</p>
            <p><strong>User Rating:</strong> {movie.user_rating}</p>
            <p><strong>Website Rating:</strong> {movie.website_rating}</p>
          </div>
        </Grid>
      ))}
    </Grid>
  </Box>
  </div>
);

};

export default MoviePage;
