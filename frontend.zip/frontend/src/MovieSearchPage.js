import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import MoviePage from './MoviePage';
import { Card, CardMedia} from '@mui/material';

const MovieSearchPage = () => {
  const [searched, setSearched] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [movieData, setMovieData] = useState(null); // State to store movie data

  const containerStyle = {
    height: '100%',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    background: 'linear-gradient(135deg, #f6d365, #fda085)',
    padding: '16px',
    position: 'relative',
    paddingBottom: '100%',
    paddingTop: '10%',
  
  };
  
  const searchContainerStyle = {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: '16px',
    position: 'relative',
  };

  const searchInputStyle = {
    width: '200px',
    marginBottom: '20px'// Add margin to the right of the search input
  };

  const buttonStyle = {
    backgroundColor: 'black',
    color: 'white', // Add margin to the left of the button
    position: 'fixed',
    top: '5px',
    left: '5px',
    marginTop: '5%' // Position the button to the right within the container
  };

  const handleSearch = () => {
    fetch('http://127.0.0.1:5000/api/search', {  // Updated endpoint to match backend running on port 5000
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query: searchInput }),
    })
    .then(response => response.json())
    .then(data => {
      setMovieData(data); // Update movieData state with the response from the backend
      setSearched(true);
    })
    .catch(error => console.error('Error:', error));
  };
  

  const handleBack = () => {
    setSearched(false);
  };

  return (
    <div style={containerStyle}>
      {!searched && (
        <>
          <Card sx={{ maxWidth: 345, backgroundColor: 'transparent', boxShadow: 'none'}}>
            <CardMedia
                component="img"
                height="140"
                image="\logo.png" // or provide a valid image URL
                alt="Your Image"
            />
        </Card>
          <Typography variant="h4" gutterBottom>
            The Movie Lounge
          </Typography>
          <Typography variant="subtitle1" gutterBottom>
            Looking for a Movie? Search here:
          </Typography>
          
          <div style={searchContainerStyle}>
            <TextField
              id="searchInput"
              style={searchInputStyle}
              label="Search"
              variant="outlined"
              size="small"
              value={searchInput}
              marginRight='25px'
              onChange={(e) => setSearchInput(e.target.value)}
            />
            <Button
              variant="contained"
              onClick={handleSearch}
              sx={{
                marginRight: '0px',
                backgroundColor: 'black',
                marginBottom: '20px',
                marginLeft: '5px'
              }}
            >
              Search
            </Button>
          </div>
        </>
        
      )}
      {searched && (
        <>
          <Button
            variant="contained"
            style={buttonStyle}
            onClick={handleBack}
          >
            Back
          </Button>
          {/* Pass movieData as props to MoviePage component */}
          <MoviePage movieData={movieData} />
        </>
      )}
    </div>
  );
};

export default MovieSearchPage;
